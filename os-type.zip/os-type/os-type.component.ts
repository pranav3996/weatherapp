import { Component, OnInit } from '@angular/core';
import { OSTypeService } from './os-type.service';
import { OSType } from './os-type.model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-os-type',
  templateUrl: './os-type.component.html',
  styleUrls: ['./os-type.component.scss'],
})
export class OSTypeComponent implements OnInit {
  allTableData: any[] = [];
  tableData: any[] = [];
  selectedRow: any = {};
  infraRoleID = 0;
  osTypeName: string = '';

  activeStatus: boolean | undefined;

  isEditMode: boolean = false;

  editingRoleId: number | null = null;

  constructor(private osTypeService: OSTypeService, private http: HttpClient) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.osTypeService.getAllOSType().subscribe((data) => {
      console.log('get data', data);

      this.allTableData = data;
      this.tableData = data; // Initially display all data
    });
  }

  onSubmit() {
    if (this.editingRoleId !== null) {
      const payload = {
        osTypeName: this.osTypeName,
        activeStatus: this.activeStatus,
        infraRoleID: this.editingRoleId,
      };
      // Assuming updateData() is a method to send data to the server
      this.updateData(this.editingRoleId, payload);
      this.osTypeName = '';
      this.activeStatus=undefined;
      // this.activeStatus = null;
    } else {
      const osNameValue = this.osTypeName;
      const data: OSType = {
        osTypeName: this.osTypeName,
        activeStatus: this.activeStatus as boolean,
      };

      this.osTypeService.saveOSType(osNameValue, data).subscribe((response) => {
        console.log('post data', data);
        this.tableData.push(data);

        this.loadData();
        this.osTypeName = '';
        this.activeStatus=undefined;
      });
    }
  }

  isSearchButtonDisabled: boolean = false;
  editRow(infraRoleID: number) {
    this.isSearchButtonDisabled = true;
    const item = this.tableData.find((i) => i.infraRoleID === infraRoleID);
    if (item) {
      this.osTypeName = item.osTypeName;
      this.activeStatus = item.activeStatus;
      this.editingRoleId = infraRoleID;
      this.isEditMode = true;
    }
  }

  updateData(infraRoleID: number, payload: any) {
    console.log(payload);

    this.osTypeService.updateOS(infraRoleID, payload).subscribe({
      next: (response) => {
        const index = this.tableData.findIndex(
          (i) => i.infraRoleID === infraRoleID
        );
        if (index !== -1) {
          this.tableData[index] = { ...this.tableData[index], ...payload };
        }
        this.resetForm();
        this.editingRoleId = null;
      },
      error: (error) => {
        console.error('Error updating data:', error);
      },
    });
    this.isEditMode = false;
  }

  deleteRow(infraRoleID: number): void {
    this.osTypeService.deleteOSType(infraRoleID).subscribe(
      (data) => {
        console.log(data);

        this.loadData();
      },
      (error) => console.error(error)
    );
  }

  resetForm(): void {
    this.osTypeService.getAllOSType().subscribe((data) => {
      this.tableData = data;
    });
  }

  onSearch() {
    const activeStatus = this.activeStatus;

    if (activeStatus !== undefined) {
      this.osTypeService.searchUser(this.osTypeName, activeStatus).subscribe(
        (data) => {
          this.tableData = data;
          this.osTypeName = '';
          this.activeStatus=undefined;
        },
        (error) => {
          console.error('Error occurred while searching:', error);
        }
      );
    } else {
      this.osTypeService.searchUser(this.osTypeName).subscribe(
        (data) => {
          this.tableData = data;
          this.osTypeName = '';
          this.activeStatus=undefined;
        },
        (error) => {
          console.error('Error occurred while searching:', error);
        }
      );
    }
  }
}
