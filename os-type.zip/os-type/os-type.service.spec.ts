import { TestBed } from '@angular/core/testing';

import { OSTypeService } from './os-type.service';

describe('OSTypeService', () => {
  let service: OSTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OSTypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
