export interface OSType {
    osTypeName: string;
    activeStatus: boolean;
    infraRoleID?: number;
  }