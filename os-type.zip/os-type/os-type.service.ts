import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { OSType } from './os-type.model';

@Injectable({
  providedIn: 'root'
})
export class OSTypeService {




  private apiUrl = 'https://localhost:7291/api/OSTypeMaster';

  constructor(private http: HttpClient) { }

  getAllOSType(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

 saveOSType(value:string,data: OSType): Observable<any> {
  return this.http.post(`${this.apiUrl}/?osName=${value}`, data);
}
updateOS(infraRoleID: number, payload: any): Observable<any> {
  return this.http.put(`${this.apiUrl}/${infraRoleID}`, payload);
}

deleteOSType(id: any): Observable<any>{
  return this.http.delete(`${this.apiUrl}/${id}`);
}

searchOSType(value:string):Observable<any>{
  return this.http.get(`${this.apiUrl}/OSTypeName?OSTypeName=${value}`);
}


searchUser(query?: string, value?: boolean): Observable<any> {

  let params = new HttpParams();
  if (query !== undefined) {
    params = params.append('OSTypeName', query);
  }
  
  if (value !== undefined) {
    params = params.append('activeStatus', value.toString());
  }

  return this.http.get(`${this.apiUrl}/OSTypeNameAndStatusCode`, { params });
}


}