import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OSTypeComponent } from './os-type.component';

describe('OSTypeComponent', () => {
  let component: OSTypeComponent;
  let fixture: ComponentFixture<OSTypeComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [OSTypeComponent]
    });
    fixture = TestBed.createComponent(OSTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
